#!/bin/sh

echo "========================== navi start shell running..."
ebNav="navigation_car2"
EB_PATH=/koteinavidata



cd "$EB_PATH" 
chmod 755 /$ebNav
/$ebNav 

